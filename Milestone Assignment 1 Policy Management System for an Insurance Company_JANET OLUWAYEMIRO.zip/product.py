# product.py

class Product:
    def __init__(self, product_id, name, price, status="available"):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.status = status

    def update_price(self, new_price):
        self.price = new_price
        print(f"Product {self.name} price updated to {self.price}.")

    def suspend(self):
        if self.status == "available":
            self.status = "suspended"
            print(f"Product {self.name} has been suspended.")
        else:
            print(f"Product {self.name} is already suspended.")

    def __str__(self):
        return f"Product ID: {self.product_id}, Name: {self.name}, Price: {self.price}, Status: {self.status}"

