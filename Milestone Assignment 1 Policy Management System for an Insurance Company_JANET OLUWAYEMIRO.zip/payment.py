# payment.py

from datetime import datetime, timedelta

class Payment:
    def __init__(self, payment_id, policyholder_id, product_id, amount, due_date):
        self.payment_id = payment_id
        self.policyholder_id = policyholder_id
        self.product_id = product_id
        self.amount = amount
        self.due_date = due_date
        self.status = "pending"

    def process_payment(self):
        self.status = "paid"
        print(f"Payment {self.payment_id} processed successfully.")

    def send_reminder(self):
        if self.status == "pending":
            print(f"Reminder: Payment {self.payment_id} is due on {self.due_date}.")
        else:
            print(f"Payment {self.payment_id} has already been processed.")

    def apply_penalty(self):
        if self.status == "pending" and datetime.now() > self.due_date:
            self.amount += 10  # Adding penalty
            print(f"Penalty applied to Payment {self.payment_id}. New amount: {self.amount}")

    def __str__(self):
        return f"Payment ID: {self.payment_id}, Policyholder ID: {self.policyholder_id}, Product ID: {self.product_id}, Amount: {self.amount}, Status: {self.status}"

