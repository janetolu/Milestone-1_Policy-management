{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 23,
   "id": "8f5dac70-d579-4d3d-a151-f172be47a686",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Policyholder ID: 1, Name: John Doe, Status: active\n",
      "Policyholder John Doe has been suspended.\n",
      "Policyholder ID: 1, Name: John Doe, Status: suspended\n",
      "Policyholder John Doe has been reactivated.\n",
      "Policyholder ID: 1, Name: John Doe, Status: active\n",
      "Product ID: 1, Name: Health Insurance, Price: 500, Status: available\n",
      "Product Health Insurance price updated to 600.\n",
      "Product Health Insurance has been suspended.\n",
      "Product ID: 1, Name: Health Insurance, Price: 600, Status: suspended\n",
      "Payment ID: 101, Policyholder ID: 1, Product ID: 1, Amount: 500, Status: pending\n",
      "Reminder: Payment 101 is due on 2024-12-28 18:12:13.434271.\n",
      "Payment 101 processed successfully.\n",
      "Payment 101 has already been processed.\n",
      "\n",
      "Policyholder Details:\n",
      "Policyholder ID: 1, Name: John Doe, Status: active\n",
      "Policyholder ID: 2, Name: Jane Smith, Status: active\n"
     ]
    }
   ],
   "source": [
    "# main.py\n",
    "\n",
    "from policyholder import Policyholder\n",
    "from product import Product\n",
    "from payment import Payment\n",
    "from datetime import datetime, timedelta\n",
    "\n",
    "# Create Products\n",
    "product1 = Product(product_id=1, name=\"Health Insurance\", price=500)\n",
    "product2 = Product(product_id=2, name=\"Life Insurance\", price=1000)\n",
    "\n",
    "# Create Policyholders\n",
    "policyholder1 = Policyholder(policyholder_id=1, name=\"John Doe\")\n",
    "policyholder2 = Policyholder(policyholder_id=2, name=\"Jane Smith\")\n",
    "\n",
    "# Create Payments\n",
    "payment1 = Payment(payment_id=101, policyholder_id=1, product_id=1, amount=500, due_date=datetime.now() + timedelta(days=7))\n",
    "payment2 = Payment(payment_id=102, policyholder_id=2, product_id=2, amount=1000, due_date=datetime.now() + timedelta(days=5))\n",
    "\n",
    "# Demonstrate Policyholder Actions\n",
    "print(policyholder1)\n",
    "policyholder1.suspend()\n",
    "print(policyholder1)\n",
    "policyholder1.reactivate()\n",
    "print(policyholder1)\n",
    "\n",
    "# Demonstrate Product Actions\n",
    "print(product1)\n",
    "product1.update_price(600)\n",
    "product1.suspend()\n",
    "print(product1)\n",
    "\n",
    "# Demonstrate Payment Actions\n",
    "print(payment1)\n",
    "payment1.send_reminder()\n",
    "payment1.process_payment()\n",
    "payment1.send_reminder()\n",
    "\n",
    "# Display Policyholder Details\n",
    "print(\"\\nPolicyholder Details:\")\n",
    "print(policyholder1)\n",
    "print(policyholder2)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 25,
   "id": "234299c4-38fa-47ee-b66f-51c6bc5bc272",
   "metadata": {},
   "outputs": [
    {
     "ename": "NameError",
     "evalue": "name 'zipfile' is not defined",
     "output_type": "error",
     "traceback": [
      "\u001b[1;31m---------------------------------------------------------------------------\u001b[0m",
      "\u001b[1;31mNameError\u001b[0m                                 Traceback (most recent call last)",
      "Cell \u001b[1;32mIn[25], line 5\u001b[0m\n\u001b[0;32m      2\u001b[0m files_to_zip \u001b[38;5;241m=\u001b[39m [\u001b[38;5;124m\"\u001b[39m\u001b[38;5;124mpolicyholder.py\u001b[39m\u001b[38;5;124m\"\u001b[39m, \u001b[38;5;124m\"\u001b[39m\u001b[38;5;124mproduct.py\u001b[39m\u001b[38;5;124m\"\u001b[39m, \u001b[38;5;124m\"\u001b[39m\u001b[38;5;124mpayment.py\u001b[39m\u001b[38;5;124m\"\u001b[39m, \u001b[38;5;124m\"\u001b[39m\u001b[38;5;124mmain.py\u001b[39m\u001b[38;5;124m\"\u001b[39m, \u001b[38;5;124m\"\u001b[39m\u001b[38;5;124mREADME.md\u001b[39m\u001b[38;5;124m\"\u001b[39m]\n\u001b[0;32m      4\u001b[0m \u001b[38;5;66;03m# Create ZIP file\u001b[39;00m\n\u001b[1;32m----> 5\u001b[0m \u001b[38;5;28;01mwith\u001b[39;00m zipfile\u001b[38;5;241m.\u001b[39mZipFile(\u001b[38;5;124m\"\u001b[39m\u001b[38;5;124mAssignment_Files.zip\u001b[39m\u001b[38;5;124m\"\u001b[39m, \u001b[38;5;124m\"\u001b[39m\u001b[38;5;124mw\u001b[39m\u001b[38;5;124m\"\u001b[39m) \u001b[38;5;28;01mas\u001b[39;00m zipf:\n\u001b[0;32m      6\u001b[0m     \u001b[38;5;28;01mfor\u001b[39;00m file \u001b[38;5;129;01min\u001b[39;00m files_to_zip:\n\u001b[0;32m      7\u001b[0m         zipf\u001b[38;5;241m.\u001b[39mwrite(file)\n",
      "\u001b[1;31mNameError\u001b[0m: name 'zipfile' is not defined"
     ]
    }
   ],
   "source": [
    "# Files to include\n",
    "files_to_zip = [\"policyholder.py\", \"product.py\", \"payment.py\", \"main.py\", \"README.md\"]\n",
    "\n",
    "# Create ZIP file\n",
    "with zipfile.ZipFile(\"Assignment_Files.zip\", \"w\") as zipf:\n",
    "    for file in files_to_zip:\n",
    "        zipf.write(file)\n",
    "\n",
    "print(\"ZIP file created: Project_Files.zip.zip\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "3914fe3f-a3ef-40a1-b51b-79a40f6136bd",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.4"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
