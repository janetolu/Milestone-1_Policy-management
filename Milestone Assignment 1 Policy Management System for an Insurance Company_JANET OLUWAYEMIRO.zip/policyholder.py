# policyholder.py

class Policyholder:
    def __init__(self, policyholder_id, name, status="active"):
        self.policyholder_id = policyholder_id
        self.name = name
        self.status = status

    def suspend(self):
        if self.status == "active":
            self.status = "suspended"
            print(f"Policyholder {self.name} has been suspended.")
        else:
            print(f"Policyholder {self.name} is already suspended.")

    def reactivate(self):
        if self.status == "suspended":
            self.status = "active"
            print(f"Policyholder {self.name} has been reactivated.")
        else:
            print(f"Policyholder {self.name} is already active.")

    def __str__(self):
        return f"Policyholder ID: {self.policyholder_id}, Name: {self.name}, Status: {self.status}"

